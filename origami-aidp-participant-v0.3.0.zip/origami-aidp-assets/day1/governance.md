# Governance checkpoint · 10 minutes

Trace C0001 / R0001 from data/claims.csv to Bronze, Silver and the matching Lakehouse claim row (5 min). Inspect the facilitator's actual allowed/denied tool-access trace for your assigned identity (5 min). Save the references.

contracts/lineage.csv is a declared map, not proof of native runtime lineage. Folder naming, a prompt guardrail or a local test is not proof of AIDP permission isolation. If the live denial trace is missing, mark this check incomplete. No IAM changes are performed during class.
