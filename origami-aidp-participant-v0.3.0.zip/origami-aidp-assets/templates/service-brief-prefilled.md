# SYNTHETIC EXAMPLE — replace with your actual test evidence

Status: DRAFT / UNREVIEWED
Member: M001 (p01 example; use your assigned slot member)
Inquiry date: 2026-09-01
Inquiry: CONSULT evidence across two plans

| Plan | Structured usage | Document limit | Citation |
|---|---:|---:|---|
| BASE 2026 | 2 visits | 12 visits/year | BASE-2026 / CONSULT |
| PLUS 2026 | 1 visit | 6 visits/year | PLUS-2026 / CONSULT |

Gap: coordination-of-benefits rules are not supplied. Do not sum limits or choose coverage automatically.
Proposed next step: representative reviews coordination rules.
Actual tool/answer references: NOT YET RECORDED
Reviewer/decision/timestamp/rationale: NOT YET RECORDED
No final coverage, eligibility, fraud, payment or medical decision.
