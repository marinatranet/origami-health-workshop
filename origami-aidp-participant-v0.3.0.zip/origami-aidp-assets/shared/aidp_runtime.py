"""AIDP adapter for the bounded Origami workshop. Requires administrator runtime bindings."""
import json
import os
import re
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from origami_core import AS_OF, SOURCES, fingerprint

LIMIT = 1500  # Small workshop fixture only; reject larger data instead of unbounded driver collection.

def configuration():
    config_path=os.environ.get('ORIGAMI_RUNTIME_CONFIG')
    if not config_path: raise RuntimeError('Administrator must set ORIGAMI_RUNTIME_CONFIG; no live defaults are embedded.')
    cfg=json.loads(Path(config_path).read_text(encoding='utf-8'))
    if any('REPLACE' in str(v) for v in cfg.values()):raise ValueError('Administrator runtime placeholders are unresolved')
    if not re.fullmatch(r'p(?:0[1-9]|1[0-9]|20)',cfg.get('participant_id','')): raise ValueError('Invalid participant slot')
    root=cfg.get('output_root','')
    if not root.startswith('/Volumes/') or not root.endswith('/origami/runs/'+cfg['participant_id']) or '..' in root.split('/'):
        raise ValueError('Output root must be the assigned /Volumes/.../origami/runs/pNN path')
    for name in ('target_catalog','target_schema'):
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',cfg.get(name,'')): raise ValueError('Administrator must bind '+name)
    if cfg['target_schema']!='ORIGAMI_'+cfg['participant_id'].upper():raise ValueError('Unexpected participant target schema')
    cfg['asset_root']=str(Path(os.environ['ORIGAMI_ASSET_ROOT']).resolve())
    return cfg

def canonical(rows):
    result=[]
    for row in rows:
        values=row.asDict() if hasattr(row,'asDict') else dict(row)
        result.append({k:int(v) if isinstance(v,Decimal) and v==v.to_integral_value() else str(v) if isinstance(v,Decimal) else v for k,v in values.items()})
    return result

def bounded_rows(frame):
    rows=frame.limit(LIMIT+1).collect()
    if len(rows)>LIMIT:raise ValueError('Bounded workshop collection limit exceeded')
    return canonical(rows)

def unique(frame, keys):
    if frame.groupBy(*keys).count().where('count > 1').limit(1).count():raise ValueError('Duplicate key: '+','.join(keys))
    from pyspark.sql import functions as F
    for key in keys:
        if frame.where(F.col(key).isNull()).limit(1).count():raise ValueError('Null key: '+key)

def delta_path(cfg,name):
    if not re.fullmatch(r'(bronze|silver|gold)_[a-z_]+',name):raise ValueError('Unexpected output name')
    return cfg['output_root']+'/'+name

def persist(spark,cfg,name,frame,keys):
    if cfg.get('allow_workshop_writes') is not True:raise PermissionError('Writes disabled in runtime configuration')
    if len(frame.columns)!=len(set(frame.columns)):raise ValueError('Repeated output column name')
    unique(frame,keys)
    before=bounded_rows(frame)
    path=delta_path(cfg,name)
    # Explicit full-snapshot contract within the assigned disposable workshop namespace only.
    frame.write.format('delta').mode('overwrite').option('overwriteSchema','true').save(path)
    reread=spark.read.format('delta').load(path)
    expected=[(f.name,f.dataType.simpleString()) for f in frame.schema.fields]
    actual=[(f.name,f.dataType.simpleString()) for f in reread.schema.fields]
    assert actual==expected,'Persisted schema mismatch'
    unique(reread,keys)
    assert fingerprint(bounded_rows(reread))==fingerprint(before),'Persisted contents differ'
    return reread

def read_delta(spark,cfg,name):return spark.read.format('delta').load(delta_path(cfg,name))

def source_frame(spark,cfg,name):
    if name not in SOURCES:raise ValueError(name)
    contract=json.loads((Path(cfg['asset_root'])/'contracts'/'expected.json').read_text())
    from pyspark.sql.types import StructType,StructField,StringType
    columns=contract['source_columns'][name]
    schema=StructType([StructField(c,StringType(),False) for c in columns])
    return spark.read.option('header','true').option('mode','FAILFAST').schema(schema).csv(str(Path(cfg['asset_root'])/'data'/f'{name}.csv'))

def verify_fixture(spark,cfg,name,frame):
    expected=json.loads((Path(cfg['asset_root'])/'contracts'/'expected.json').read_text())
    rows=bounded_rows(frame)
    assert len(rows)==expected['counts'][name],f'Unexpected row count for {name}'
    assert fingerprint(rows)==expected['fingerprints'][name],f'Fixture mismatch for {name}'

def publish_snapshot(spark,cfg,name,source,keys):
    """Single writer per participant. Same-snapshot insert-only replay; changed rows fail closed."""
    if cfg.get('allow_lakehouse_writes') is not True:raise PermissionError('Lakehouse writes disabled')
    if name not in ('claim_detail','claims_monthly','member_plan','benefit_usage','benefit_schedule'):raise ValueError(name)
    target=f"{cfg['target_catalog']}.{cfg['target_schema']}.origami_{name}"
    existing=spark.table(target)  # Pre-created target is mandatory; no implicit DDL.
    assert [c.lower() for c in existing.columns]==source.columns,'Target column order does not match DDL'
    existing=existing.toDF(*source.columns)
    from pyspark.sql import functions as F
    casted=source.select(*[F.col(c).cast(field.dataType).alias(c) for c,field in zip(source.columns,existing.schema.fields)])
    original=bounded_rows(source); converted=bounded_rows(casted)
    assert fingerprint(original)==fingerprint(converted),'Target casts would change values'
    unique(existing,keys);unique(casted,keys)
    wanted={tuple(r[k] for k in keys):r for r in converted}
    for row in bounded_rows(existing):
        assert wanted.get(tuple(row[k] for k in keys))==row,'Existing target row is outside or differs from this snapshot; stop for administrator review'
    new=casted.join(existing.select(*keys),keys,'left_anti').select(*source.columns)
    if new.limit(1).count():new.write.mode('append').insertInto(target)
    final=spark.table(target).toDF(*source.columns)
    unique(final,keys)
    assert fingerprint(bounded_rows(final))==fingerprint(converted),'Lakehouse reconciliation failed'
    return final

def save_evidence(cfg,name,value):
    if not re.fullmatch(r'[a-z0-9_-]+',name):raise ValueError(name)
    target=Path(cfg['output_root'])/'evidence'
    target.mkdir(parents=True,exist_ok=True)
    record={'participant_id':cfg['participant_id'],'captured_at_utc':datetime.now(timezone.utc).isoformat(),'as_of_date':AS_OF,'evidence':value}
    (target/(name+'.json')).write_text(json.dumps(record,indent=2,default=str),encoding='utf-8')
    print('Saved participant evidence:',name)
