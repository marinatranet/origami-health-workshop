"""Deterministic, bounded synthetic reference logic. No cloud/network operations."""
import csv
import hashlib
import json
import math
import random
from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

SEED = 42
AS_OF = '2026-09-01'
VERSION = 'origami-health-1.0'
FEATURES = ['log_amount', 'missing_attachment', 'prior_duplicate_signal']
SOURCES = ['members', 'plans', 'enrollments', 'providers', 'claims', 'benefit_schedule', 'benefit_usage']

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest()

def fingerprint(rows):
    return digest(sorted(json.dumps(r, sort_keys=True, separators=(',', ':'), default=str) for r in rows))

def synthetic_sources(seed=SEED):
    rng = random.Random(seed)
    members = [{'member_id': f'M{i:03}', 'slot_id': f'p{(i-1)//3+1:02}', 'segment': 'SYNTHETIC', 'region': ['NORTH','CENTRAL','SOUTH'][i % 3]} for i in range(1,61)]
    plans = [dict(plan_id='BASE', plan_version='2025', effective_from='2025-01-01', effective_to='2025-12-31', document_id='BASE-2025'), dict(plan_id='BASE', plan_version='2026', effective_from='2026-01-01', effective_to='2026-12-31', document_id='BASE-2026'), dict(plan_id='PLUS', plan_version='2026', effective_from='2026-01-01', effective_to='2026-12-31', document_id='PLUS-2026')]
    enrollments = []
    for m in members:
        enrollments.append(dict(enrollment_id='E'+m['member_id']+'B', member_id=m['member_id'], plan_id='BASE', plan_version='2026', start_date='2026-01-01', end_date='2026-12-31', enrollment_status='ACTIVE'))
        if int(m['member_id'][1:]) % 3 == 1:
            enrollments.append(dict(enrollment_id='E'+m['member_id']+'P', member_id=m['member_id'], plan_id='PLUS', plan_version='2026', start_date='2026-01-01', end_date='2026-12-31', enrollment_status='ACTIVE'))
            enrollments.append(dict(enrollment_id='E'+m['member_id']+'H', member_id=m['member_id'], plan_id='BASE', plan_version='2025', start_date='2025-01-01', end_date='2025-12-31', enrollment_status='EXPIRED'))
    providers = [{'provider_id':f'P{i:02}', 'provider_name':f'Fictional Provider {i}', 'specialty':'GENERAL', 'network_status':'IN_NETWORK'} for i in range(1,7)]
    schedule = []
    for p in plans:
        for service, limit, unit in [('CONSULT', '12' if p['plan_id']=='BASE' else '6', 'visits_per_year'), ('DIAG', '5000' if p['plan_id']=='BASE' else '8000', 'PHP_per_year')]:
            schedule.append(dict(benefit_id=f"{p['document_id']}-{service}", plan_id=p['plan_id'], plan_version=p['plan_version'], service_code=service, limit_value=limit if p['plan_version']=='2026' else '4', limit_unit=unit, effective_from=p['effective_from'], effective_to=p['effective_to'], document_id=p['document_id'], section=service, exclusions='COSMETIC not described as a benefit', requirement='Representative review; no automatic coverage decision'))
    usage = [dict(usage_id=e['enrollment_id']+'-CONSULT', member_id=e['member_id'], enrollment_id=e['enrollment_id'], service_code='CONSULT', used_value='2' if e['plan_id']=='BASE' else '1', unit='visits', as_of_date=AS_OF) for e in enrollments if e['plan_version']=='2026']
    claims, outcomes = [], []
    for i in range(1,721):
        member = members[(i-1)%60]
        amount = rng.randint(500,9000)
        missing = int(rng.random() < .18)
        duplicate = int(rng.random() < .09)
        event = date(2026,1,1) + timedelta(days=(i-1)//4)
        probability = 1/(1+math.exp(-(-6 + .00055*amount + 2.7*missing + 3.5*duplicate)))
        label = int(rng.random() < probability)
        if i == 601:
            amount, missing, duplicate, label = 24000, 0, 0, 0
        row = dict(source_record_id=f'R{i:04}', claim_id=f'C{i:04}', member_id=member['member_id'], enrollment_id='E'+member['member_id']+'B', provider_id=f'P{i%6+1:02}', service_code=['CONSULT','DIAG'][i%2], service_date=event.isoformat(), submitted_amount=f'{amount}.00', paid_amount=f'{amount//2}.00', currency='PHP', status=['PAID','PENDING','DENIED'][i%3], processing_days=str(i%15+1), missing_attachment=str(missing), prior_duplicate_signal=str(duplicate), feature_available_date=event.isoformat())
        claims.append(row)
        outcomes.append(dict(claim_id=row['claim_id'], synthetic_review_required=label, label_observed_date=(event+timedelta(days=7)).isoformat(), note='Legitimate high-value fixture' if i==601 else 'Synthetic review label; not confirmed fraud'))
    # One deterministic duplicate and four independent bad rows, all original values retained in Bronze.
    claims.append(dict(claims[0], source_record_id='R0721'))
    for n, change in enumerate([{'member_id':'M999'}, {'submitted_amount':'not-a-number'}, {'provider_id':'P99'}, {'service_date':'2026-02-30'}],722):
        claims.append(dict(claims[n-722], source_record_id=f'R{n:04}', claim_id=f'C{n:04}', **change))
    return dict(zip(SOURCES,[members,plans,enrollments,providers,claims,schedule,usage])), outcomes

def valid_date(value):
    try:
        return date.fromisoformat(value).isoformat() == value
    except (TypeError, ValueError):
        return False

def cents(value):
    try:
        n = Decimal(value)
        if not n.is_finite() or n < 0 or n*100 != (n*100).to_integral_value():
            return None
        return int(n*100)
    except (InvalidOperation, TypeError, ValueError):
        return None

def conform(src):
    """Reference for the Spark Silver notebook; one evaluation per raw claim."""
    members={r['member_id'] for r in src['members']}
    providers={r['provider_id'] for r in src['providers']}
    enroll={r['enrollment_id']:r for r in src['enrollments']}
    seen, accepted, rejected, duplicates = set(), [], [], []
    for raw in sorted(src['claims'], key=lambda r:r['source_record_id']):
        if raw['claim_id'] in seen:
            duplicates.append(dict(raw, reject_reason='DUPLICATE_CLAIM'))
            continue
        seen.add(raw['claim_id'])
        amount, paid = cents(raw['submitted_amount']), cents(raw['paid_amount'])
        e=enroll.get(raw['enrollment_id'])
        failures=[]
        if raw['member_id'] not in members: failures.append('MEMBER_REFERENCE')
        if raw['provider_id'] not in providers: failures.append('PROVIDER_REFERENCE')
        if amount is None or paid is None or (paid is not None and amount is not None and paid>amount): failures.append('AMOUNT')
        if not valid_date(raw['service_date']): failures.append('SERVICE_DATE')
        if not e or e['member_id']!=raw['member_id'] or not(e['start_date']<=raw['service_date']<=e['end_date']): failures.append('ENROLLMENT')
        if raw['currency']!='PHP': failures.append('CURRENCY')
        if failures:
            rejected.append(dict(raw, reject_reason='|'.join(failures)))
        else:
            accepted.append(dict(claim_id=raw['claim_id'], member_id=raw['member_id'], enrollment_id=raw['enrollment_id'], provider_id=raw['provider_id'], service_code=raw['service_code'], service_date=raw['service_date'], submitted_centavos=amount, paid_centavos=paid, currency=raw['currency'], status=raw['status'], processing_days=int(raw['processing_days']), missing_attachment=int(raw['missing_attachment']), prior_duplicate_signal=int(raw['prior_duplicate_signal']), feature_available_date=raw['feature_available_date'], source_record_id=raw['source_record_id']))
    assert len(src['claims']) == len(accepted)+len(rejected)+len(duplicates)
    return accepted,rejected,duplicates

def gold(src, accepted):
    groups=defaultdict(lambda:dict(claim_count=0, submitted_centavos=0, paid_centavos=0, processing_days_sum=0))
    for r in accepted:
        key=(r['service_date'][:7],r['provider_id'],r['service_code'])
        g=groups[key]
        for k,v in [('claim_count',1),('submitted_centavos',r['submitted_centavos']),('paid_centavos',r['paid_centavos']),('processing_days_sum',r['processing_days'])]:g[k]+=v
    monthly=[dict(service_month=k[0],provider_id=k[1],service_code=k[2],currency='PHP',**v) for k,v in sorted(groups.items())]
    plans={(r['plan_id'],r['plan_version']):r for r in src['plans']}
    member_plans=[dict(e,document_id=plans[e['plan_id'],e['plan_version']]['document_id']) for e in src['enrollments']]
    return {'claim_detail':accepted,'claims_monthly':monthly,'member_plan':member_plans,'benefit_usage':src['benefit_usage'],'benefit_schedule':src['benefit_schedule']}

def active_plans(rows, member_id, inquiry_date, authorized_member_ids):
    """Authorization set must come from a trusted server-side identity map, never a prompt."""
    if member_id not in authorized_member_ids: raise PermissionError('MEMBER_SCOPE_DENIED')
    if not valid_date(inquiry_date): raise ValueError('INVALID_DATE')
    return [r for r in rows if r['member_id']==member_id and r['enrollment_status']=='ACTIVE' and r['start_date']<=inquiry_date<=r['end_date']]

def feature(row):
    return [math.log1p(row['submitted_centavos']/100),float(row['missing_attachment']),float(row['prior_duplicate_signal'])]

def probability(row, model):
    f=feature(row)
    z=model['intercept']+sum(w*(x-m)/s for w,x,m,s in zip(model['weights'],f,model['means'],model['scales']))
    return 1/(1+math.exp(-max(-40,min(40,z))))

def fit_model(accepted, outcomes):
    labels={r['claim_id']:r for r in outcomes}
    train=[r for r in accepted if r['service_date']<'2026-04-01' and labels[r['claim_id']]['label_observed_date']<='2026-04-01']
    val=[r for r in accepted if '2026-04-01'<=r['service_date']<'2026-05-01' and labels[r['claim_id']]['label_observed_date']<='2026-05-01']
    test=[r for r in accepted if r['service_date']>='2026-05-01']
    for split in (train,val,test):
        assert {labels[r['claim_id']]['synthetic_review_required'] for r in split}=={0,1}
        assert all(r['feature_available_date']<=r['service_date'] for r in split)
    features=[feature(r) for r in train]
    means=[sum(r[j] for r in features)/len(features) for j in range(3)]
    scales=[max(1e-9,math.sqrt(sum((r[j]-means[j])**2 for r in features)/len(features))) for j in range(3)]
    x=[[(r[j]-means[j])/scales[j] for j in range(3)] for r in features]
    y=[labels[r['claim_id']]['synthetic_review_required'] for r in train]
    w,b=[0.,0.,0.],0.
    # Fixed learning rate, regularization and iteration count; no holdout tuning.
    for _ in range(800):
        errors=[1/(1+math.exp(-max(-40,min(40,b+sum(a*c for a,c in zip(w,row))))))-label for row,label in zip(x,y)]
        b-=.12*sum(errors)/len(x)
        w=[a-.12*(sum(err*row[j] for err,row in zip(errors,x))/len(x)+.015*a) for j,a in enumerate(w)]
    model=dict(version='origami-review-logistic-1.0', algorithm='standardized_logistic_regression', features=FEATURES, means=means,scales=scales,weights=w,intercept=b,threshold=.5,seed=SEED,training_cutoff='2026-04-01',training_rows=len(train),training_fingerprint=fingerprint(train),target='synthetic_review_required',classification='SYNTHETIC; investigator prioritization only',registry_status='NOT_REGISTERED',endpoint_status='NOT_DEPLOYED')
    model['artifact_digest']=digest(model)
    evaluation={name:metrics(rows,labels,model) for name,rows in [('train',train),('validation',val),('test',test)]}
    assert evaluation['test']['roc_auc']>=.65 and evaluation['test']['average_precision']>evaluation['test']['prevalence'], 'Model quality gate failed'
    return model,evaluation

def metrics(rows,labels,model):
    pairs=[(probability(r,model),labels[r['claim_id']]['synthetic_review_required'],r['claim_id']) for r in rows]
    ranked=sorted(pairs,key=lambda x:(-x[0],x[2])); positive=sum(y for _,y,_ in pairs); negative=len(pairs)-positive
    auc=sum((a>b)+.5*(a==b) for a,y,_ in pairs if y for b,z,_ in pairs if not z)/(positive*negative)
    hits=0; ap=0.
    for n,(_,y,_) in enumerate(ranked,1):
        hits+=y
        if y:ap+=hits/n
    tp=sum(p>=.5 and y==1 for p,y,_ in pairs); fp=sum(p>=.5 and y==0 for p,y,_ in pairs)
    fn=positive-tp; tn=negative-fp
    precision=tp/max(1,tp+fp); recall=tp/positive
    return dict(rows=len(rows),positive=positive,prevalence=positive/len(rows),roc_auc=auc,average_precision=ap/positive,precision=precision,recall=recall,f1=2*precision*recall/max(1e-12,precision+recall),tp=tp,fp=fp,fn=fn,tn=tn,queue_share=(tp+fp)/len(rows),precision_at_20=sum(y for _,y,_ in ranked[:20])/min(20,len(ranked)),baseline='No-skill average precision equals prevalence; not measured customer performance')

def score_rows(rows,model):
    assert model['features']==FEATURES
    check=dict(model); expected=check.pop('artifact_digest'); assert digest(check)==expected,'Model digest mismatch'
    out=[]
    for r in rows:
        p=probability(r,model)
        f=feature(r)
        contributions=[w*(x-m)/s for w,x,m,s in zip(model['weights'],f,model['means'],model['scales'])]
        reasons=[FEATURES[i] for i in sorted(range(3),key=lambda i:-contributions[i]) if contributions[i]>0]
        out.append(dict(claim_id=r['claim_id'],review_score=round(p,10),review_priority='REVIEW' if p>=model['threshold'] else 'ROUTINE',reason_codes='|'.join(reasons) or 'baseline',model_version=model['version'],model_digest=model['artifact_digest'],as_of_date=AS_OF,guardrail='Synthetic review priority; not proof of fraud or a coverage decision'))
    return out

def write_csv(path, rows):
    assert rows
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)

def read_csv(path):
    with path.open(encoding='utf-8',newline='') as stream:return list(csv.DictReader(stream))
