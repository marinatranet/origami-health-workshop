# Origami Health — AIDP participant assets

Start with ASSET_MAP.md. This version matches the website's two 90-minute AIDP sessions. All records and benefits are fictional. No original customer data, credentials or runtime identifiers are included.

Included: six unexecuted notebook files, seven CSV sources, explicit expected results, prepared locally trained model, current/archived benefits documents, retrieval and Copilot tests, and evidence/review templates.

Prerequisites: facilitator-prepared AIDP access, warm Spark with Delta, read-only asset volume, isolated output paths, prepared Lakehouse targets and runtime bindings. Put the FULL pack in the prepared shared asset path; importing a notebook alone is not sufficient. Administrator deployment inputs must remain private and outside this pack.

Not included: a verified AIDP agent export, a built knowledge-base index, credentials, OAC assets, registered-model evidence or a cloud deployment claim. contracts/copilot-design.json is a bounded design, not a deployable bundle. Current live agent availability is UNVERIFIED. Do not treat local tests as live permission, RAG, model-registry or endpoint tests.

All notebooks fail closed without runtime configuration. No final coverage/eligibility/payment/fraud or medical decision is automated. Validate the prepared cloud environment and run a classroom-style timing pilot before delivery.
