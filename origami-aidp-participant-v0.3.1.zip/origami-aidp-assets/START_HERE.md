# Start here — first-time participant

This is a prepared, synthetic Origami Health workshop, not a production insurance system. You run and inspect supplied cells; infrastructure setup, model training and agent wiring belong to the facilitator before class.

## Before opening a notebook

1. Obtain your own approved login, assigned workspace, notebook copy and participant slot privately.
2. Confirm with the facilitator that the correct workshop environment and prepared compute are selected. Do not infer the environment from the public website or notebook filename.
3. Use the full participant pack. The notebooks require shared helpers, CSV data, model and contracts—not just the .ipynb files.
4. Do not edit credentials, catalog bindings, participant IDs or paths to fix access problems. Ask the facilitator.

## Run one cell at a time

Read the explanation above a code cell, then run that cell using the notebook editor’s run-cell control. Wait for it to finish and inspect the output before advancing. The exact button label can vary by installed interface. Do not use Run all on your first pass. A number beside a cell is execution order, not evidence that the business checks passed. A red error means stop at that cell.

Run the binding cell at the beginning of every notebook. If your session restarts, Python variables are lost; ask the facilitator which completed stages can safely be reused before rerunning write cells. Never restart shared compute yourself.

## Core route and duration

Day 1: 00 setup (20 min); 01 Bronze and 02 Silver together (30 min); 03 Gold and 04 Lakehouse together (20 min); governance (10 min); catch-up (10 min). Total 90 min.

Day 2: readiness (5 min); 05 scoring (15 min); 06 knowledge-base guide (15 min); 07 Copilot guide (35 min); 08 human review (10 min); catch-up (10 min). Total 90 min. Files 06–08 are guided Markdown exercises, not executable notebooks or an importable agent.

Optional discussion is after the core checkpoint or outside class. Do not turn the catch-up allowance into extra mandatory content.

## Troubleshooting — stop safely

| Symptom | What to do |
|---|---|
| Missing ORIGAMI_ASSET_ROOT or ORIGAMI_RUNTIME_CONFIG | Ask the facilitator to bind your prepared session; do not paste someone else’s config. |
| Import/module missing or source file missing | Check the FULL asset pack is mounted at the assigned path; ask the facilitator. Do not install packages into shared compute. |
| Spark is undefined, session detached or indefinitely queued | Confirm assigned compute with the facilitator. Do not create/start/restart a cluster yourself. |
| Table not found or permission denied | Stop; report notebook, cell heading and sanitized error. Do not create tables or change grants. |
| Fingerprint, row-count or target-value assertion fails | Preserve the output and stop. Do not disable the assertion, change the expected result or repeatedly replay writes. |
| Previous cell failed or variables are undefined | Return to the first failed cell with facilitator guidance, rather than continuing downstream. |
| Copilot returns no citation or another member’s information | Mark the test failed and notify the facilitator. Never relax scope to make the test pass. |

## Record evidence, not just expected answers

Use templates/evidence-sheet.md. Save your actual output, observed result, notebook/cell reference and status privately. If the facilitator supplies a recovery snapshot, label the live step incomplete and the continuation as a fallback. Never claim that reading a policy manually proves live retrieval works.

No final fraud, eligibility, coverage, treatment or payment decision is automated. Synthetic data still needs correct participant access controls. Keep credentials and raw session traces out of public GitHub issues and screenshots.
