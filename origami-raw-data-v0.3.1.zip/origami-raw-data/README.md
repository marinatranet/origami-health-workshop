# Origami Health raw data

Seven synthetic CSV sources and their data contract. No credentials or private runtime bindings. For the runnable AIDP notebooks and helper files, download the separate participant execution pack.
