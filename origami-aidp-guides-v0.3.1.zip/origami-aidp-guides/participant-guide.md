# Origami Health — Hands-on Data, Analytics & AI Workshop

Each AIDP hands-on session is planned for 90 minutes using prepared, tested assets. Day 1 includes 20 minutes of setup checks, 60 minutes of guided exercises and 10 minutes of catch-up; Day 2 includes 5 minutes of readiness, 75 minutes of guided exercises and 10 minutes of catch-up. Timing is an estimate until a classroom-style pilot passes. Separate slides, breaks and Q&A share the remaining 90 minutes of each three-hour day. No clock times are displayed. OAC is separately owned and its draft is unchanged.

Asset preview available: notebooks, synthetic data, prepared model and exercise files are locally validated. See the release readiness checklist for facilitator rehearsal results. Knowledge-base/agent deployment, class access and timed delivery remain pending.

Claims, Benefits, Provider and Member Operations: build trusted data, investigate unusual claims, answer benefit inquiries with evidence, and explore operational and retail opportunities.

## Delivery assumptions — prepared assets

- Before class: participant accounts and permissions are tested, notebooks are imported, compute is warm, and source data, output schemas and the Lakehouse connection are ready.
- Day 2 starts with a validated Day 1 snapshot, a prepared scorer, an indexed benefits knowledge base and a preconnected Copilot. Training, indexing, tool connections and deployment are not participant tasks.
- Core tasks are mandatory; optional tasks are take-home or fast-finisher work. Catch-up time is reserved for assistance and saving results, not additional content.
- A timed pilot must include a participant unfamiliar with the instructions and representative concurrent load. Record actual completion and any fallback used; an instructor-only run does not validate class timing.

## Half-Day 1 · Setup and access check — allow 15–20 minutes

Use this 20-minute allowance to sign in to the prepared AIDP workspace, confirm your participant folder and isolated schema, open starter notebook 01, select the already-running compute and run the supplied read-only access check against the source volume and Lakehouse. Confirm the recovery snapshot and where to save evidence. This is an access check, not platform provisioning or software installation. Ask the facilitator to resolve failed checks; if still blocked, pair with a working participant and record what remains unresolved. If setup finishes in 15 minutes, use the remaining five minutes as lab support buffer within the same 90-minute block.

Save: A completed access checklist or a recorded blocker and agreed paired-work fallback.

Files in the participant asset pack:

- day1/00_setup_check.ipynb

## Half-Day 1 · Lab 1: Build Bronze and Silver HMO data products (30 min)

Turn claims, members, enrollment, plans and provider inputs into traceable, conformed data products.

### Before you begin

- Assigned participant folder and schema; running Spark compute; prepared synthetic source files and starter notebooks.
- The facilitator supplies the asset root, output root and participant identifier. Seven CSV sources include claims, members, plans, enrollments, providers, benefits and usage; document-related flags are precomputed synthetic inputs, not a live document extraction integration.

### Steps

1. Confirm your participant paths and snapshot date in starter notebook 01 (3 minutes).
2. Run the prepared Bronze cells and inspect the lineage fields and count summary (7 minutes, including execution).
3. Run the prepared Silver cells. Locate one quarantined invalid reference and explain why it failed; transformations and joins are provided (12 minutes, including execution).
4. Compare accepted, rejected and deduplicated counts with the supplied expected results; save the summary for Lab 2 (8 minutes).

### Check your result

- The supplied count reconciliation passes; the chosen rejected row has an understandable reason.
- Your output is in the assigned participant location; the read-only source remains unchanged.

Save: A reconciliation summary and an explanation of one rejected record.

### Files in the participant asset pack

- day1/01_bronze.ipynb
- day1/02_silver.ipynb

### Optional / take-home — outside the core timebox

- Inspect multi-plan enrollment joins and precomputed document-evidence flags.
- Write a new transformation or rerun the complete pipeline from scratch.

### Facilitator preparation — before class

- Facilitator: verify the full key/reference test suite, participant isolation and expected counts before class. Run-time and queuing must fit inside the stated timeboxes.
- If a live run cannot finish, identify the facilitator recovery snapshot explicitly and record the live task as incomplete; viewing a snapshot is not successful execution.

## Half-Day 1 · Lab 2: Publish Claims and Benefits data to AI Lakehouse (20 min)

Expose consistent data for claims analysis, claim-level investigation and authorized member-benefit inquiry.

### Before you begin

- Lab 1 passes; participant tables, grants and the external catalog are prepared.
- The participant model includes both claims analytics and member/plan benefit access; monthly claim aggregates alone cannot answer individual member questions.

### Steps

1. Inspect the prepared grain diagram and assigned target; do not configure the database connection (3 minutes).
2. Run the selected notebook 03 Gold cells, followed by the prepared notebook 04 Lakehouse cells (7 minutes, including execution).
3. Run two supplied checks: claim count/amount reconciliation and a dated active-plan lookup for one synthetic member (7 minutes).
4. Save the two query results and snapshot reference for Day 2 (3 minutes).

### Check your result

- Claim counts and amounts match expected results without join fan-out.
- The dated lookup returns the expected active plans for the authorized synthetic member.

Save: Two validated query results and the Day 2 snapshot reference.

### Files in the participant asset pack

- day1/03_gold.ipynb
- day1/04_lakehouse.ipynb

### Optional / take-home — outside the core timebox

- Inspect full duplicate/orphan/overlap checks and repeat-run evidence.
- Author workflow dependencies, connection settings or new Lakehouse tables.

### Facilitator preparation — before class

- Facilitator: prepare tables, grants, connections and query templates; verify full schemas, foreign keys, benefit versions, scope and unchanged-source rerun behavior ahead of class.
- This timebox assumes Gold and Lakehouse execution fits the seven-minute allowance under representative concurrency. Record a recovery snapshot as fallback rather than completed live publishing.

## Half-Day 1 · Governance exercise

Trace one supplied synthetic claim from source through Silver to a Gold view (5 minutes). Inspect one prepared allowed/denied access test and explain where scope is enforced (5 minutes). Full role setup, workflow authoring and native-lineage verification are facilitator preparation or follow-up work; declared lineage is not proof of runtime-native lineage.

Save: A record trace and a role-to-data access check.

Files in the participant asset pack:

- day1/governance.md

## Half-Day 1 · Catch-up and save results — 10 minutes

Use this reserved time for help, pending core checks and saving the reconciliation/query evidence. Do not add new mandatory content. Record incomplete live tasks and any recovery snapshot used.

Save: Saved Day 1 evidence and an honest completion checklist.

## Half-Day 2 · Day 2 readiness check

Reconnect, open the assigned scorer, knowledge base and preconnected Copilot, and confirm the validated Day 1 snapshot. Account fixes and deployment are pre-class tasks. Escalate any blocker to the facilitator rather than attempting a fresh setup.

Save: Readiness confirmed or a recorded blocker.

## Half-Day 2 · Lab 3: Score claims anomalies for investigation (15 min)

Prioritize unusual claims for investigator review and explain the supporting signals.

### Before you begin

- Prepared features, synthetic investigation outcomes, a seeded experiment and pre-trained model. Full training and AutoML configuration are facilitator preparation or take-home activities.
- A claim denial is not a fraud label. The original denial-risk notebook is a learning reference, not this lab's fraud model.

### Steps

1. Inspect the prepared feature/label card and its human-review boundary (3 minutes).
2. Run the prepared scorer and open the review queue (5 minutes, including execution).
3. Inspect one flagged claim and the supplied legitimate/false-positive example; explain the reason code without asserting fraud (5 minutes).
4. Save the claim reference, score/model version and one review observation (2 minutes).

### Check your result

- The selected score has a model/version reference and evidence supporting its review priority.
- The explanation distinguishes an unusual claim from confirmed fraud.

Save: One annotated investigation example with its score/version reference.

### Files in the participant asset pack

- day2/05_claim_scoring.ipynb
- model/prepared_model.json

### Optional / take-home — outside the core timebox

- Inspect precision/recall and review-capacity tradeoffs in the seeded experiment.
- Run training, compare AutoML candidates or change thresholds.

### Facilitator preparation — before class

- Facilitator: train the model, verify leakage-safe splits, evaluation and registered-model/batch-scorer parity; preflight scoring and provide seeded results as a labelled fallback.

## Half-Day 2 · Lab 4: Test the Benefits Knowledge Base (15 min)

Retrieve the right benefit passage for the right plan, service and effective date.

### Before you begin

- Fictional Origami Health benefit guides, plan schedules, exclusions, FAQs and service procedures with document IDs, versions and effective dates.
- A validated, pre-ingested knowledge base and participant permissions are ready before class. Source configuration, ingestion and index creation are facilitator preparation or take-home extensions.

### Steps

1. Open the prepared knowledge base and inspect the plan/version metadata (3 minutes).
2. Ask one supplied benefit-limit question and verify its cited passage, plan, version and inquiry date (6 minutes).
3. Ask one unsupported-service question and confirm an insufficient-evidence response rather than an invented policy (4 minutes).
4. Save the two results and citations or refusal explanation (2 minutes).

### Check your result

- The supported answer cites the expected current plan document and section.
- The unsupported answer reports the evidence gap without inventing benefit terms.

Save: Two retrieval checks: one supported answer and one unsupported question.

### Files in the participant asset pack

- day2/06_benefits_knowledge_base.md
- day2/retrieval-tests.json
- documents/ingestion-manifest.json

### Optional / take-home — outside the core timebox

- Test exclusions, document requirements, expired versions and conflicting passages.
- Create or ingest a new knowledge base.

### Facilitator preparation — before class

- Facilitator: ingest/index the documents and independently test exclusions, expired plans, conflicting evidence and irrelevant retrieval before class.

## Half-Day 2 · Lab 5: Adapt and test the Member Benefits Inquiry Copilot (35 min)

Help a service representative answer an inquiry by combining authorized member-plan facts with cited benefit documents.

### Before you begin

- A tested, preconnected supervisor/SQL/RAG starter is assigned to each participant. Model, tool bindings, permissions and member scope are configured before class.
- SQL tools enforce authorized member scope outside the prompt. The participant changes an answer instruction, not access controls.

### Steps

1. Open the working starter and trace supervisor → bounded SQL/RAG tools → evidence-based answer (5 minutes).
2. Change one response instruction to require plan/version citations and explicit evidence gaps; save your assigned copy (5 minutes).
3. Run three supplied cases: an authorized SQL lookup, a combined two-plan benefit inquiry and an unauthorized-member request. Compare against the answer checklist and tool traces (18 minutes, including responses).
4. Save the results and use the combined answer to populate the prepared service-brief template (7 minutes).

### Check your result

- The authorized lookup matches the prepared expected facts; the combined answer has current citations and identifies unresolved coordination rules.
- The unauthorized request is rejected by the tool/data boundary, not just by prompt instructions.
- The Copilot makes no final coverage, eligibility, denial, payment or medical decision.

Save: One instruction change, three test results and a draft service brief.

### Files in the participant asset pack

- day2/07_member_benefits_copilot.md
- day2/copilot-tests.json
- contracts/copilot-design.json

### Optional / take-home — outside the core timebox

- Change supervisor routing or add an additional answer-format instruction.
- Inspect and rerun the facilitator's policy-conflict and prompt-injection tests.

### Facilitator preparation — before class

- Facilitator: establish and validate all tool connections, model access and member-scope enforcement before class. Verify SQL-only, RAG-only, combined, missing-policy, conflict and prompt-injection cases separately.
- RAG-only practice is completed in Lab 4; creating an agent, connecting tools from scratch and endpoint deployment are outside this timebox.

Example questions:

- For my authorized synthetic member and the selected inquiry date, show the active plans and relevant benefit usage. Explain the source of each fact.
- What does the current benefit guide say about this service, including limits, exclusions and required documents? Cite the plan and section.
- This synthetic member has two active plans. Compare the relevant evidence, identify missing coordination rules and draft a service brief for a representative to review.
- The plan data and policy passage disagree. Show the conflict, avoid a definitive coverage answer and identify the review required.

## Half-Day 2 · Human-in-the-loop service brief

Review the prefilled brief from the Copilot exercise (4 minutes): verify member/plan context, structured facts, cited policy and any gaps. Mark REVIEWED, EDIT_REQUIRED or ESCALATED and record a reason (4 minutes). Save the reviewer decision and timestamp (2 minutes). This is review of a draft, not approval of coverage or payment. No case is created and no message is sent.

Save: A completed brief with reviewer decision, timestamp and rationale.

Files in the participant asset pack:

- day2/08_human_review.md
- templates/service-brief-prefilled.md

## Half-Day 2 · Catch-up and save results — 10 minutes

Use the buffer for response delays, questions, pending core checks and saving the reviewed brief. Optional challenges do not displace core tasks or extend the session.

Save: Saved Day 2 evidence and an honest completion checklist.
